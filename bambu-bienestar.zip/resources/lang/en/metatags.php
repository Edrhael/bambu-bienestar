<?php

return [
	'default' => [
		'metaTitle' => 'Bamboo Wellness',
		'metaDescription' => 'Welcome to Bamboo Wellness, a place to find peace and balance.',
		'metaKeywords' => 'wellness, relaxation, health, yoga',
		'metaImage' => 'images/default.png',
		'metaRobots' => 'index, follow',
	],
	'home' => [
		'metaTitle' => 'Home | Bamboo Wellness',
		'metaDescription' => 'Discover the path to wellness with our relaxation and yoga practices.',
		'metaKeywords' => 'wellness, yoga, relaxation, health',
		'metaImage' => 'images/inicio.png',
		'metaRobots' => 'index, follow',
	],

];
