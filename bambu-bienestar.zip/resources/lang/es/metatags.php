<?php

return [
	'default' => [
		'metaTitle' => 'Bambú Bienestar',
		'metaDescription' => 'Bienvenido a Bambú Bienestar, un lugar para encontrar paz y equilibrio.',
		'metaKeywords' => 'bienestar, relajación, salud, yoga',
		'metaImage' => 'images/default.png',
		'metaRobots' => 'index, follow',
	],
	'home' => [
		'metaTitle' => 'Inicio | Bambú Bienestar',
		'metaDescription' => 'Descubre el camino hacia el bienestar con nuestras prácticas de relajación y yoga.',
		'metaKeywords' => 'bienestar, yoga, relajación, salud',
		'metaImage' => 'images/inicio.png',
		'metaRobots' => 'index, follow',
	],
];
