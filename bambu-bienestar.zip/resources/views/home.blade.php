@extends('default-layout')

@section('title', 'Bambú Bienestar')

@section('content')
    <h2>¡Bienvenido a Bambú Bienestar!</h2>
    <p>Este es el inicio de tu proyecto en Laravel.</p>
@endsection
