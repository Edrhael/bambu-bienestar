@extends('default-layout')

@section('title', 'Bambú Bienestar - Pilates')

@section('content')

    <h2>Pilates</h2>

@endsection
