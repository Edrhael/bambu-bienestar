<footer>

    <a href="{{ route('legalAdvice') }}" style="margin-right: 10px; color: white;">Aviso Legal</a>

    &copy; {{ date('Y') }} Bambú Bienestar. Todos los derechos reservados.

</footer>

</body>
</html>
