<header>

	<a href="{{ route('selectLanguage', 'es') }}">Español</a> |
	<a href="{{ route('selectLanguage', 'en') }}">English</a>


	<header>Bambú Bienestar</header>

    <nav class="main-menu">
        <a href="{{ route('home') }}" class="main-menu-option {{ request()->routeIs('home') ? 'activeSection' : '' }}">
            Inicio
        </a>
        <a href="{{ route('pilates') }}" class="main-menu-option {{ request()->routeIs('pilates') ? 'activeSection' : '' }}">
            Pilates
        </a>
{{--        <a href="{{ route('laragon') }}" class="main-menu-option">Test</a>--}}
        <a href="{{ route('contact') }}" class="main-menu-option {{ request()->routeIs('contact') ? 'activeSection' : '' }}">
            Contacto
        </a>
    </nav>

</header>
