@extends('default-layout')

@section('title', 'Bambú Bienestar - Contacto')

@section('content')
    <h2>Contacto</h2>

@endsection
