<!DOCTYPE html>
<html lang="es">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title', 'Bambú Bienestar'); ?></title>

    <style>
        body {
            font-family: 'Comfortaa', Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 1rem;
            text-align: center;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 1rem;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
        .content {
            padding: 2rem;
        }
    </style>

</head>

<body>

<header>
    <h1>Bambú Bienestar</h1>
    <nav>
        <a href="/" style="margin-right: 10px; color: white;">Inicio</a>
        <a href="/pilates" style="margin-right: 10px; color: white;">Pilates</a>
        <a href="/test" style="margin-right: 10px; color: white;">Test</a>
        <a href="/contacto" style="color: white;">Contacto</a>
    </nav>
</header>

<main class="content">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<footer>

    <a href="/aviso-legal" style="margin-right: 10px; color: white;">Aviso Legal</a>

    &copy; <?php echo e(date('Y')); ?> Bambú Bienestar. Todos los derechos reservados.

</footer>

</body>
</html>
<?php /**PATH D:\Development\laragon\www\bambu-bienestar\resources\views/default-layout.blade.php ENDPATH**/ ?>
