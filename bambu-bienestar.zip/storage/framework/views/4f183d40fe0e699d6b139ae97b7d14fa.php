<header>

	<a href="<?php echo e(route('selectLanguage', 'es')); ?>">Español</a> |
	<a href="<?php echo e(route('selectLanguage', 'en')); ?>">English</a>


	<header>Bambú Bienestar</header>

    <nav class="main-menu">
        <a href="<?php echo e(route('home')); ?>" class="main-menu-option <?php echo e(request()->routeIs('home') ? 'activeSection' : ''); ?>">
            Inicio
        </a>
        <a href="<?php echo e(route('pilates')); ?>" class="main-menu-option <?php echo e(request()->routeIs('pilates') ? 'activeSection' : ''); ?>">
            Pilates
        </a>

        <a href="<?php echo e(route('contact')); ?>" class="main-menu-option <?php echo e(request()->routeIs('contact') ? 'activeSection' : ''); ?>">
            Contacto
        </a>
    </nav>

</header>
<?php /**PATH D:\Development\laragon\www\bambu-bienestar\resources\views/partials/header.blade.php ENDPATH**/ ?>