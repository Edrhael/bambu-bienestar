<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo e($metaTitle ?? 'Bambú Bienestar'); ?></title>

<meta name="description" content="<?php echo e($metaDescription ?? 'Bienvenido a Bambú Bienestar, un lugar para encontrar paz y equilibrio.'); ?>">
<meta name="keywords" content="<?php echo e($metaKeywords ?? 'bienestar, relajación, salud, yoga'); ?>">
<meta name="author" content="<?php echo e($metaAuthor ?? 'Bambú Bienestar'); ?>">
<meta name="robots" content="<?php echo e($metaRobots ?? 'index, follow'); ?>">
<meta name="theme-color" content="#4CAF50">

<!-- Open Graph -->
<meta property="og:title" content="<?php echo e($metaTitle ?? 'Bambú Bienestar'); ?>">
<meta property="og:description" content="<?php echo e($metaDescription ?? 'Bienvenido a Bambú Bienestar.'); ?>">
<meta property="og:image" content="<?php echo e($metaImage ?? asset('images/default.png')); ?>">
<meta property="og:url" content="<?php echo e($metaUrl ?? url()->current()); ?>">
<meta property="og:type" content="website">

<!-- Twitter Cards -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo e($metaTitle ?? 'Bambú Bienestar'); ?>">
<meta name="twitter:description" content="<?php echo e($metaDescription ?? 'Bienvenido a Bambú Bienestar.'); ?>">
<meta name="twitter:image" content="<?php echo e($metaImage ?? asset('images/default.png')); ?>">
<?php /**PATH D:\Development\laragon\www\bambu-bienestar\resources\views/partials/metatags.blade.php ENDPATH**/ ?>