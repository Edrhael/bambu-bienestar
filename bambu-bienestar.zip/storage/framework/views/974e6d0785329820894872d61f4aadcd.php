<footer>

    <a href="<?php echo e(route('legalAdvice')); ?>" style="margin-right: 10px; color: white;">Aviso Legal</a>

    &copy; <?php echo e(date('Y')); ?> Bambú Bienestar. Todos los derechos reservados.

</footer>

</body>
</html>
<?php /**PATH D:\Development\laragon\www\bambu-bienestar\resources\views/partials/footer.blade.php ENDPATH**/ ?>