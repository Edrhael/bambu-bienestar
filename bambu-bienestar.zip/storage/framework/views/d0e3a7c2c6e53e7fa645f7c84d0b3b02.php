<?php echo $__env->make('partials.metatags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<title><?php echo $__env->yieldContent('title', 'Bambú Bienestar'); ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@100..900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/styles.css')); ?>">

<style>
    header {
		width: 100%;
		padding: 1rem;
		text-align: center;
		color: white;
		background-color: #4CAF50;
    }
	header header {
		font-size: 36px;
	}
    footer {
        background-color: #333;
        color: white;
        text-align: center;
        padding: 1rem;
        //position: fixed;
        bottom: 0;
        width: 100%;
    }
    .content {
        padding: 2rem;
    }
    .main-menu{
        display: flex;
        justify-content: center;
        gap: 24px;
    }
    .main-menu-option {
        color: white;
        text-decoration: none;
    }
    .main-menu-option.activeSection{
        font-weight: 600;
    }

</style>
<?php /**PATH D:\Development\laragon\www\bambu-bienestar\resources\views/partials/head.blade.php ENDPATH**/ ?>